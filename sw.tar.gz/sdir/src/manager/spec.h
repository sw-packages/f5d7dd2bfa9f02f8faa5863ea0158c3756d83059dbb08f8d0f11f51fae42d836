// Copyright (C) 2016-2018 Egor Pugin <egor.pugin@gmail.com>
//
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.

#pragma once

#include "package.h"
#include "source.h"

#include <primitives/date_time.h>

#define SPEC_FILE_EXTENSION ".cppan"

namespace sw
{

struct Specification
{
    Package package;
    Source source;
    String cppan;
    String hash;
    TimePoint created;
};

Specification download_specification(const Package &pkg);
Specification read_specification(const String &spec);
Specification read_specification(const ptree &spec);

}
